Coloca aquí tus artefactos reales: plan.json, policy_result.txt, sbom-*.json, paquete de evidencia, etc.
